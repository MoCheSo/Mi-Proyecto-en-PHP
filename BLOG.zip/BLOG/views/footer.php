<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!-- Pie de Página -->
<footer class="page-footer pink">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">Más información</h5>
                <p class="grey-text text-lighten-4">Renuevo contenido cada Lunes a las 12:00pm hora México.</p>
            </div>
            <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Redes Sociales </h5>
                <ul>
                    <li><a class="grey-text text-lighten-3" href="https://www.instagram.com/monicherrez/?hl=es">Instagram</a></li>
                    <li><a class="grey-text text-lighten-3" href="https://www.facebook.com/monica.cherrezsolis.1/">Facebook</a></li>
                    <li><a class="grey-text text-lighten-3" href="https://twitter.com/cherrez_monica">Twitter</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            © 2021 Copyright FEMENINE WITH MONI 
        
        </div>
    </div>
</footer>      

