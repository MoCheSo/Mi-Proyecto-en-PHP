<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<h3><i>Cortes de Cabello en tendencia</i></h3>
<div class="news-cards">
    <div>
        <img src="img/cabello_rosa.jpg" alt="" />
        <h3>Cabello rosa.</h3>
        <p>
        Las personas que se tiñen el pelo de rosa buscan la inocencia, el amor, la entrega y la generosidad. Es un color del que nadie puede decir nada malo. También es un color que inspira fantasía, creatividad e ilusión.
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/corte2.jpg" alt="" />
        <h3>Flequillo "Blunt".</h3>
        <p>
        Un flequillo contundente es unas de las grandes tendencias entre los cortes de cabello, y es que sumar un flequillo es una excelente manera de crear un nuevo estilo sin el compromiso de un corte de cabello drástico o un cambio en la longitud que llevas. Este look lo vimos primero en las pasarelas otoño/invierno 2021 de Emilio Pucci y Valentino, y más recientemente en Kacey Musgraves.
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/corte 3.jpg" alt="" />
        <h3>Capas y más capas.</h3>
        <p>
        Otro look para agregar definición y volumen sin tener que sacrificar tu largo. Las capas largas, estilo ‘candelabro’, y suaves fluyen a la perfección a lo largo del contorno de tu rostro. El truco está, explican los estilistas, en delimitar las capas largas en la parte posterior de tu cabello y las capas más suaves y graduadas para enmarcar el rostro. Como estas de Sarah Hyland, quien también luce el color del año, el cobre.
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/corte4.jpg" alt="" />
        <h3>Flequillo cortina.</h3>
        <p>
        Jennifer Lopez sorprendió hace unas semanas con un flequillo de cortina sumado a su melena XL, una apuesta segura cuando se trata de rejuvenecer y suavizar facciones. El fleco a la Brigitte Bardot ha tenido un interesante comeback desde el año pasado.
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/ElgranCorte.jpg" alt="" />
        <h3>El gran corte.</h3>
        <p>
        Gabrielle Union-Wade contaba en la publicación en la que colocó esta foto que normalmente este tipo de cortes, tan drásticos, se asociaban a momentos ‘cuando todo estaba perdido’ y te cortabas el cabello para simbolizar ese cambio, pero en su caso quiso ser un ejemplo de que también es posible apostar por este ‘gran corte’ cuando todo está bien y solo deseas recuperar tus rizos, sanarlos y descubrir una nueva melena. Y como demuestra ella misma o Sanaa Lathan lo demuestran, no es necesario raparte, si eso no es lo que quieres, puedes dejarlo un poco más largo en la parte superior y bajito por los lados, o que sea todo uniforme. 
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/flequillo baby.jpg" alt="" />
        <h3>Flequillo Baby.</h3>
        <p>
            El tercer flequillo más popular de esta temporada, aunque no se crea, es el ‘baby’. ¿Quizá ‘Gambito de dama’ tenga algo que ver con esto? Este estilo normalmente sigue la línea del cabello de la sien a la sien, para crear una sensación dramática, corta y abierta. Por lo que funcionan muy bien para las personas con rasgos pequeños para abrir su rostro. Su estilo es imperfecto, pero ideal para quienes ya tienen flequillo y buscan una nueva manera de actualizarlo. 
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/asimetricoCORTE.jpg" alt="" />
        <h3>Asimétrico.</h3>
        <p>
        Hay tantas versiones para los cortes de cabello asimétrico que todo depende de cuán drásticos te gustaría que fueran los largos. Sin duda alguna hablamos de un estilo muy vanguardista que podrás llevarlo en un liso perfecto o en una versión en ondas, como lo hace la actriz Rosamund Pike, al ras de su barbilla. 
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="img/corte_lob.jpg" alt="" />
        <h3>Lob.</h3>
        <p>
        Uno de los cortes de cabello por excelencia de bajo mantenimiento es el bob largo, o ‘long bob = lob’. Es el estilismo ideal para un corte más desenfadado, relajado y messy, lo que significa que cuando crezca seguirá luciendo effortless. El largo de este corte un poco desestructurado llega a la clavícula, lo que te permite lucir un bob y aún así poder recogerte la melena cuando lo desees. Para lucir perfectamente liso y suave o con textura y volumen, como este de Margot Robbie, de acuerdo a la ocasión y tu look. 
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
</div>


