<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<!-- SHOWCASE -->
<header class="showcase">
<section id="Bienvenidos">
     <h2><i>Bienvenidos</i></h2>
     <p>
        Este es un blog de Salud y belleza lo he creado con el
        propósito de compartir las mil ideas de outfits impactantes que tengo en mente, rutinas de ejercicio y darte recetas de comidas ricas y nutritivas.
        <br>Espero sea de tu agrado todo lo que te comparto en este blog dedicado para ti.
     </p>    
 </section>

 <section id="banner">
     <img src="img/globos.jpg" width="1000" height="500" alt=""> <!---Imagen que tendrá mi web.-->
    <div class="contenedor">
        <h2>Calendario de Retos fit</h2>
        <p>¿Empezamos?</p>
        <a href="views/gym.php" class="btn pink">Leer más<i class="fas fa-chevron-right"></i></a>
    </div>
 </section>

    <br>
    <br>
    
    
</header>
