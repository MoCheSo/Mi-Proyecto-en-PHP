<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<header class="showcase">
<section id="Bienvenidos">
     <h2><i>Acerca de...</i></h2>
     <p>
        Como primera entrada del Blog me parece correcto explicarles por encima quién soy, 
        a que me dedico y lo más importante e interesante para todos los lectores, de que 
        hablaré en el Blog.<br>  
        Aunque va todo muy relacionado empezaré diciendo que me llamo Monica y nací en 
        Campeche, hace ya 21 años, en la actualidad vivo en el mismo Campechito, soy
        estudiante de ingeniería en Sistemas Computacionales y aun vivo con mis padres.<br>  
        En la actualidad solo me dedico a estudiar pero en mis ratos libres me gusta hacer ejercicio, ver 
        artículos de moda y cocinar recetas saludables.
        <br> Este blog de Salud y belleza lo he creado con el
        propósito de compartir las mil ideas de outfits impactantes que tengo en mente y darte recetas de comidas ricas y nutritivas.
        <br>Espero sea de tu agrado todo lo que te comparto en este blog dedicado para ti.
     </p>    
 </section>