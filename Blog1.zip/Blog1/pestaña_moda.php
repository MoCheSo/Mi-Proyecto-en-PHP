<!DOCTYPE html> 
<html lang="es">



<head>
    <title>Mi Blog</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="widht=device-width, 
    user-scalable=no, initial-scale=1, maximum-scale=1, 
    minimum-scale=1">

    <link rel="stylesheet" href="estilos/fontello.css">
    <link rel="stylesheet" href="estilos/estilos.css">
</head>



<body>
    <?php
    ?>
<header>
    <div class="contenedor">
        <h1 class="icon-female">Feminine with Moni</h1> <!---le ponemos el icono que buscamos en fontello.--->
        <input type="checkbox" id="menu-bar"> <!---para hacer la barra de menu--->
        <label class="icon-menu" for="menu-bar"></label><!---A este igual le ponemos el icono que buscamos en fontello.--->
    
        <nav class="menu"><!---Hacemos nuestra barra de navegación--->
            <a href="index.php">Inicio</a><!---Vamos asignandole los nombres de cada etiqueta de nuestra barra.--->
            <a href="pestaña_moda.php">Moda</a>
            <a href="">Salud</a>
            <a href="">Contacto</a>
        </nav>
    </div>
</header>


<main><!---Todo lo que está dentro del main va ser el contenido principal de mi página--->
 <section id="banner">
     <img src="img/moda_banner.jpg" alt=""> <!---Imagen que tendrá mi web.-->
    <div class="contenedor">
        <h2>MODA</h2>
        <p>¿Cuál estilo te favorece según GLAMOUR?</p>
        <a href="https://www.glamour.es/moda/tendencias/galerias/como-vestir-segun-tu-tipo-de-cuerpo/11354">Leer más</a>
    </div>
 </section>

 <section id="contenedor">
     <h2>CORTES DE CABELLO QUE SERÁN TENDENCIA EN OTOÑO 2021</h2><br>
     <p>
        <h3>‘Nota mental: al regresar de las vacaciones de verano es necesario investigar sobre 
        los nuevos cortes de cabello de la temporada’. ¡Y aquí los tenemos! No tienes que ir
         más lejos porque sé que esta es una de las búsquedas indispensables luego de 
         tantos días con la melena expuesta al sol, al cloro de las albercas o la sal de la playa.</h3><br>

        Si te hiciste un corte preventivo antes de tomar tus vacaciones quizá no lo veas como algo
         urgente, pero si ese no fue tu caso, quizá sí necesites recuperar tu cabello con algo más
          que una hidratación y limpieza de puntas. Así que mi recomendación es que vayas 
          agendando una cita con tu estilista para un buen corte de cabello, y no te preocupes porque
           toda la inspiración que necesitas la conseguirás en esta galería. <br>
        
        Te propongos 4 cortes de cabello que no solo pondrán un poco de orden al daño que 
        hayan podido ocasionar los agentes externos en tu pelo, sino diferentes estilos para todo 
        tipo de melenas que busquen ese cambio, para comenzar esta nueva temporada, con looks que 
        rebosan frescura y pura tendencia. <br>
     </p>    
 </section>

 <section id="blog">
  
    <p>
        <h3>No el típico mullet de los 80´s</h3><br>
        Sí, el mullet proviene directamente de los años 80, pero como mera inspiración. No hay 
        porque tomárselo tan literal, y el mejor ejemplo de ello es el estilo que lucen Ella 
        Emhoff o Doja Cat. Una versión definitivamente más moderna y relajada, en algunos casos 
        más larga y con una onda suave que enmarca el rostro. Podríamos decir que es un híbrido 
        entre los cortes de cabello shaggy-bob-pixie-cut. Es el corte perfecto para comenzar el 
        otoño con un rotundo cambio de look, manteniendo, si así lo quieres, cierta longitud; 
        eso sí, este no será para ti si no te encanta tener el cabello en la cara. 
    </p>
    <div class="contenedor">
    
        <article>
         <img src="img/corte1.jpeg" width="700" height="300" alt="">
         <h4>No puedes dejarlo pasar. </h4>
        </article>
    </div><br><br>

    <p>
        <h3>Flequillo "Blunt"</h3><br>
        Un flequillo contundente es unas de las grandes tendencias entre los cortes de cabello, 
        y es que sumar un flequillo es una excelente manera de crear un nuevo estilo sin el compromiso
         de un corte de cabello drástico o un cambio en la longitud que llevas. Este look lo vimos primero 
         en las pasarelas otoño/invierno 2021 de Emilio Pucci y Valentino, y más recientemente en Kacey Musgraves. 
    </p>

    <div class="contenedor">
    
        <article>
         <img src="img/corte2.jpg" width="700" height="300" alt="">
         <h4>Super cute para caras largas. </h4>
        </article>
    </div><br><br>

    <p>
        <h3>Capas y más capas</h3><br>
        Otro look para agregar definición y volumen sin tener que sacrificar tu largo. Las capas largas, 
        estilo ‘candelabro’, y suaves fluyen a la perfección a lo largo del contorno de tu rostro.
         El truco está, explican los estilistas, en delimitar las capas largas en la parte posterior 
         de tu cabello y las capas más suaves y graduadas para enmarcar el rostro. Como estas de Sarah Hyland, 
         quien también luce el color del año, el cobre.  
    </p>

    <div class="contenedor">
    
        <article>
         <img src="img/corte 3.jpg" width="700" height="300" alt="">
         <h4>Luce tal cual como está linda chica. </h4>
        </article>
    </div><br><br>

    <p>
        <h3>Flequillo Cortina</h3><br>
        Jennifer Lopez sorprendió hace unas semanas con un flequillo de cortina 
        sumado a su melena XL, una apuesta segura cuando se trata de rejuvenecer 
        y suavizar facciones. El fleco a la Brigitte Bardot ha tenido un interesante 
        comeback desde el año pasado. 
    </p>

    <div class="contenedor">
    
        <article>
         <img src="img/corte4.jpg" width="700" height="300" alt="">
         <h4>Al estilo de Jlo </h4>
        </article>
    </div><br><br>
 

 <section id="info">
<h3>Te dejo unos últimos cortes que serán tendencia y que espero intentes alguno.</h3>
<div class="contenedor">
    <div class="info-pet">
        <img src="img/asimetricoCORTE.jpg" width="300" height="300"alt="">
        <h4>CORTE ASIMÉTRICO</h4>
    </div>
    <div class="info-pet">
        <img src="img/ElgranCorte.jpg" width="300" height="300" alt="">
        <h4>EL GRAN CORTE</h4>
    </div>
    <div class="info-pet">
        <img src="img/flequillo baby.jpg" width="300" height=300" alt="">
        <h4>FLEQUILLO BABY</h4>
    </div>
    <div class="info-pet">
        <img src="img/corte_lob.jpg" width="300" height="300" alt="">
        <h4>CORTE LOB</h4>
    </div>
</div>
</section>

</main>

 <footer>
<div class="contenedor">
    <p class="copy">Mode: feminine with Moni's blog &copy; 2021</p>
    <div class="sociales">
        <a class="icon-facebook-circled" href="https://www.facebook.com/monica.cherrezsolis.1/"></a>
        <a class="icon-instagram" href="https://www.instagram.com/monicherrez/?hl=es"></a>
        <a class="icon-twitter-circled" href="https://twitter.com/cherrez_monica"></a>
    </div>
</div>
 </footer>

</body>

</html>