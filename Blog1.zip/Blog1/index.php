<!DOCTYPE html> 
<html lang="es">



<head>
    <title>Bienvenida</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="widht=device-width, 
    user-scalable=no, initial-scale=1, maximum-scale=1, 
    minimum-scale=1">

    <link rel="stylesheet" href="estilos/fontello.css">
    <link rel="stylesheet" href="estilos/estilos.css">
</head>



<body>
    
    <?php
    ?>
<header>
    <div class="contenedor">
        <h1 class="icon-female">Feminine with Moni</h1> <!---le ponemos el icono que buscamos en fontello.--->
        <input type="checkbox" id="menu-bar"> <!---para hacer la barra de menu--->
        <label class="icon-menu" for="menu-bar"></label><!---A este igual le ponemos el icono que buscamos en fontello.--->
    
        <nav class="menu"><!---Hacemos nuestra barra de navegación--->
            <a href="index.php">Inicio</a><!---Vamos asignandole los nombres de cada etiqueta de nuestra barra.--->
            <a href="pestaña_moda.php">Moda</a>
            <a href="">Salud</a>
            <a href="">Contacto</a>
        </nav>
    </div>
</header>


<main><!---Todo lo que está dentro del main va ser el contenido principal de mi página--->
 <section id="banner">
     <img src="img/globos.jpg" alt=""> <!---Imagen que tendrá mi web.-->
    <div class="contenedor">
        <h2>Calendario de Retos fit</h2>
        <p>¿Empezamos?</p>
        <a href="retos.php">Leer más</a>
    </div>
 </section>

 <section id="Bienvenidos">
     <h2>BIENVENIDOS A MI BLOG DE SALUD Y BELLEZA</h2>
     <p>
        Como primera entrada del Blog me parece correcto explicarles por encima quién soy, 
        a que me dedico y lo más importante e interesante para todos los lectores, de que 
        hablaré en el Blog.<br>  
        Aunque va todo muy relacionado empezaré diciendo que me llamo Monica y nací en 
        Campeche, hace ya 21 años, en la actualidad vivo en el mismo Campechito, soy
        estudiante de ingeniería en Sistemas Computacionales y aun vivo con mis padres.<br>  
        En la actualidad solo me dedico a estudiar pero en mis ratos libres me gusta hacer ejercicio, ver 
        artículos de moda y cocinar recetas saludables.
        <br> Este blog de Salud y belleza lo he creado con el
        propósito de compartir las mil ideas de outfits impactantes que tengo en mente y darte recetas de comidas ricas y nutritivas.
        <br>Espero sea de tu agrado todo lo que te comparto en este blog dedicado para ti.
     </p>    
 </section>

 <section id="blog">
    <h3><i>Lo último de mi blog</i></h3>
 <div class="contenedor">
    
   <article>
    <img src="img/cabello_rosa.jpg" width="500" height="300" alt="">
    <h4>Tencia en cortes de cabello </h4>
   </article>

   <article>
    <img src="img/postre1.jpg" width="50" height="300"alt="">
    <h4>Postres saludables y riquisimos</h4>
   </article>

   <article>
    <img src="img/ejercicio_chica.jpg" width="50" height="300" alt="">
    <h4>Rutinas express menos de 30min</h4>
   </article>

 </div>
 </section>

 <section id="info">
<h3>Hablemos acerca de la productividad, a mi me gusta mucho tener mis dias planeados y saber que haré a cada hora para no tener contratiempos.
    <br>La idea de ser productivos es algo que todos deberiamos tener, para ser más organizados y aprovechar nuestros dias al máximo.<br>
    A continuación te dejo algunos tips para ser productivos:<br>
</h3>
<div class="contenedor">
    <div class="info-pet">
        <img src="img/dormir.jpg" width="300" height="300"alt="">
        <h4>Dormir bien y levantarse temprano.</h4>
    </div>
    <div class="info-pet">
        <img src="img/planificar.jpg" width="300" height="300" alt="">
        <h4>Planificar tus actividades a lo largo del dia.</h4>
    </div>
    <div class="info-pet">
        <img src="img/distraccion.jpg" width="300" height=300" alt="">
        <h4>Evitar distracciones en lo que haces.</h4>
    </div>
    <div class="info-pet">
        <img src="img/ordenar.jpg" width="300" height="300" alt="">
        <h4>Ordenar tu lugar de trabajo.</h4>
    </div>
    <div class="info-pet">
        <img src="img/meditar.jpg" width="300" height="300" alt="">
        <h4>Meditar o hacer ejercicio.</h4>
    </div>
</div>

<h3>Si sigues estos pequeños tips estoy segura que lograras hacer más cosas durante tu dia y lo explotarás al máximo.<br>
</h3> 
</section>

</main>

 <footer>
<div class="contenedor">
    <p class="copy">Mode: feminine with Moni's blog &copy; 2021</p>
    <div class="sociales">
        <a class="icon-facebook-circled" href="https://www.facebook.com/monica.cherrezsolis.1/"></a>
        <a class="icon-instagram" href="https://www.instagram.com/monicherrez/?hl=es"></a>
        <a class="icon-twitter-circled" href="https://twitter.com/cherrez_monica"></a>
    </div>
</div>
 </footer>

</body>

</html>
