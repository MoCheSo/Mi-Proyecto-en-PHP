<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

    <div class="contenedor">
        <h1 class="icon-female">Feminine with Moni</h1> <!---le ponemos el icono que buscamos en fontello.--->
        <input type="checkbox" id="menu-bar"> <!---para hacer la barra de menu--->
        <label class="icon-menu" for="menu-bar"></label><!---A este igual le ponemos el icono que buscamos en fontello.--->
    
        <nav class="menu"><!---Hacemos nuestra barra de navegación--->
            <a href="?menu=home">Inicio</a><!---Vamos asignandole los nombres de cada etiqueta de nuestra barra.--->
            <a href="?menu=pestaña_moda">Moda</a>
            <a href="?menu=salud">Salud</a>
            <a href="?menu=contacto">Contacto</a>
            <a href="?menu=login">Login</a>
        </nav>
    </div>

