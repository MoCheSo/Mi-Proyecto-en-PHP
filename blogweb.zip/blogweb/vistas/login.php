<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
    <body>
        <div class="container">
            <div class="row justify-content-center pt-5 mt-5 m-1">
                <div class="col-md-6 col-sm-8 col-xl-4 col-lg-5 formulario">
                    <form action="">
                        <div class="form-group text-center pt-3">
                            <h1 class="text-light"><i> INICIAR SESIÓN</i></h1>
                        </div>
                        <div class="form-group mx-sm-4 pt-3">
                            <input type="text" class="form-control" placeholder="Ingrese su Usuario">
                        </div>
                        <div class="form-group mx-sm-4 pb-3">
                            <input type="text" class="form-control" placeholder="Ingrese su Contraseña">
                        </div>
                        <div class="form-group mx-sm-4 pb-2">
                            <input type="submit" class="btn btn-block ingresar" value="INGRESAR">
                        </div>
                        <div class="form-group mx-sm-4 text-right">
                            <span class=""><a href="#" class="olvide">Olvide mi contraseña?</a></span>
                        </div>
                        <div class="form-group text-center">
                            <span><a href="" class="olvide1">REGISTRARSE</a></span>
                        </div>
                    </form>
                </div>
            </div>
        </div>



       </body>


