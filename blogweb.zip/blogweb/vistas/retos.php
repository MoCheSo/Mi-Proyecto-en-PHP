<!DOCTYPE html> 
<html lang="es">



<head>
    <title>Mi Blog</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="widht=device-width, 
    user-scalable=no, initial-scale=1, maximum-scale=1, 
    minimum-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="estilos/fontello.css">
    <link rel="stylesheet" href="estilos/estilos.css">
</head>



<body>
    <?php
    ?>
<header>
    <div class="contenedor">
        <h1 class="icon-female">Feminine with Moni</h1> <!---le ponemos el icono que buscamos en fontello.--->
        <input type="checkbox" id="menu-bar"> <!---para hacer la barra de menu--->
        <label class="icon-menu" for="menu-bar"></label><!---A este igual le ponemos el icono que buscamos en fontello.--->
    
        <nav class="menu"><!---Hacemos nuestra barra de navegación--->
            <a href="index.php">Inicio</a><!---Vamos asignandole los nombres de cada etiqueta de nuestra barra.--->
            <a href="pestaña_moda.php">Moda</a>
            <a href="">Salud</a>
            <a href="">Contacto</a>
        </nav>     
    </div>
</header>


<main><!---Todo lo que está dentro del main va ser el contenido principal de mi página--->
 <section id="banner">
     <img src="img/gym.jpg" alt=""> <!---Imagen que tendrá mi web.-->
    <div class="contenedor">
        <h2>RETO DEL MES</h2>
        <p>¡Vamos con todo!<br><br><br></p>
    </div>
 </section>




 <section id="contenedor">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>

    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="img/ejercicio1.jpg" alt="First slide">
        <div class="carousel-caption d-none d-md-block">
          <h5>Cardio hiit 20min + plancha de costado</h5>
          <p>Plancha de costado: 4 series x 15 Repeticiones</p>
        </div>
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="img/ejercicio2.jpg" alt="Second slide">
        <div class="carousel-caption d-none d-md-block">
          <h5>Entrenamiento tren superior + Curl de biceps</h5>
          <p>Curl de biceps: 5 series x 12 repeticiones</p>
        </div>
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="img/ejercicio5.jpg" alt="Third slide">
        <div class="carousel-caption d-none d-md-block">
          <h5>Caminadora 1hr</h5>
          <p>velocidad: 2 a 3 millas por hora </p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Anterior</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Siguiente</span>
    </a>
  </div>
 </section>



</main>

 <footer>
<div class="contenedor">
    <p class="copy">Mode: feminine with Moni's blog &copy; 2021</p>
    <div class="sociales">
        <a class="icon-facebook-circled" href="https://www.facebook.com/monica.cherrezsolis.1/"></a>
        <a class="icon-instagram" href="https://www.instagram.com/monicherrez/?hl=es"></a>
        <a class="icon-twitter-circled" href="https://twitter.com/cherrez_monica"></a>
    </div>
</div>
 </footer>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>

