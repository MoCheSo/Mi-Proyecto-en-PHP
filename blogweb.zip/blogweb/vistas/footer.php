<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<footer>
<div class="contenedor">
    <p class="copy">Mode: feminine with Moni's blog &copy; 2021</p>
    <div class="sociales">
        <a class="icon-facebook-circled" href="https://www.facebook.com/monica.cherrezsolis.1/"></a>
        <a class="icon-instagram" href="https://www.instagram.com/monicherrez/?hl=es"></a>
        <a class="icon-twitter-circled" href="https://twitter.com/cherrez_monica"></a>
    </div>
</div>
 </footer>