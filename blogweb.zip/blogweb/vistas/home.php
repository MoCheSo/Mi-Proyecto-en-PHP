<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<main><!---Todo lo que está dentro del main va ser el contenido principal de mi página--->
 <section id="banner">
     <img src="img/globos.jpg" alt=""> <!---Imagen que tendrá mi web.-->
    <div class="contenedor">
        <h2>Calendario de Retos fit</h2>
        <p>¿Empezamos?</p>
        <a href="vistas/retos.php">Leer más</a>
    </div>
 </section>

 <section id="Bienvenidos">
     <h2>BIENVENIDOS A MI BLOG DE SALUD Y BELLEZA</h2>
     <p>
        Como primera entrada del Blog me parece correcto explicarles por encima quién soy, 
        a que me dedico y lo más importante e interesante para todos los lectores, de que 
        hablaré en el Blog.<br>  
        Aunque va todo muy relacionado empezaré diciendo que me llamo Monica y nací en 
        Campeche, hace ya 21 años, en la actualidad vivo en el mismo Campechito, soy
        estudiante de ingeniería en Sistemas Computacionales y aun vivo con mis padres.<br>  
        En la actualidad solo me dedico a estudiar pero en mis ratos libres me gusta hacer ejercicio, ver 
        artículos de moda y cocinar recetas saludables.
        <br> Este blog de Salud y belleza lo he creado con el
        propósito de compartir las mil ideas de outfits impactantes que tengo en mente y darte recetas de comidas ricas y nutritivas.
        <br>Espero sea de tu agrado todo lo que te comparto en este blog dedicado para ti.
     </p>    
 </section>

 <section id="blog">
    <h3><i>Lo último de mi blog</i></h3>
 <div class="contenedor">
    
   <article>
    <img src="img/cabello_rosa.jpg" width="500" height="300" alt="">
    <h4>Tencia en cortes de cabello </h4>
   </article>

   <article>
    <img src="img/postre1.jpg" width="50" height="300"alt="">
    <h4>Postres saludables y riquisimos</h4>
   </article>

   <article>
    <img src="img/ejercicio_chica.jpg" width="50" height="300" alt="">
    <h4>Rutinas express menos de 30min</h4>
   </article>

 </div>
 </section>

 <section id="info">
<h3>Hablemos acerca de la productividad, a mi me gusta mucho tener mis dias planeados y saber que haré a cada hora para no tener contratiempos.
    <br>La idea de ser productivos es algo que todos deberiamos tener, para ser más organizados y aprovechar nuestros dias al máximo.<br>
    A continuación te dejo algunos tips para ser productivos:<br>
</h3>
<div class="contenedor">
    <div class="info-pet">
        <img src="img/dormir.jpg" width="300" height="300"alt="">
        <h4>Dormir bien y levantarse temprano.</h4>
    </div>
    <div class="info-pet">
        <img src="img/planificar.jpg" width="300" height="300" alt="">
        <h4>Planificar tus actividades a lo largo del dia.</h4>
    </div>
    <div class="info-pet">
        <img src="img/distraccion.jpg" width="300" height=300" alt="">
        <h4>Evitar distracciones en lo que haces.</h4>
    </div>
    <div class="info-pet">
        <img src="img/ordenar.jpg" width="300" height="300" alt="">
        <h4>Ordenar tu lugar de trabajo.</h4>
    </div>
    <div class="info-pet">
        <img src="img/meditar.jpg" width="300" height="300" alt="">
        <h4>Meditar o hacer ejercicio.</h4>
    </div>
</div>

<h3>Si sigues estos pequeños tips estoy segura que lograras hacer más cosas durante tu dia y lo explotarás al máximo.<br>
</h3> 
</section>

</main>
