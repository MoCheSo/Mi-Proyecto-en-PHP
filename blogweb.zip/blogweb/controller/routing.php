<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$var_getMenu = isset($_GET['menu']) ? $_GET['menu'] : 'inicio';
// $var_getMenu = $_GET['menu'];

switch ($var_getMenu) {
    case "inicio":
        require_once('./vistas/home.php');
        break;
    case "moda":
        require_once('.vistas/pestaña_moda.php');
        break;
    case "salud":
        require_once('./vistas/salud.php');
        break;
    case "contacto":
        require_once('./vistas/contacto.php');
        break;
    case "login":
        require_once('./vistas/login.php');
        break;
   
    default:
        require_once('./vistas/EnProceso.php');
}


?>